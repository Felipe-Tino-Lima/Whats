# WhatsApp Me Using Mobile Number , Don't need to save the Number
WhatsApp Me Using Mobile Number application 📱 built using Java ♨️ 

# ⚙️ Features 
1. Enter your desired mobile number
2. Click the button
3. go to the whatsapp and chat 



## ⚙️ Technology Used

 <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="Java" width="40" height="40"/> </a> <a href="https://www.java.com" target="_blank"> <img src="https://github.com/devicons/devicon/blob/master/icons/android/android-plain.svg" alt="Android" width="40" height="40"/> </a> <a href="https://www.java.com" target="_blank">  

## 📸 Screenshots

Soon Arrive...

## 📸 Video

Soon Arrive...

  
  <h2 align="center">📝 Created by </h2>


<h3>Amit maity</h3>

  <a href="https://linkedin.com/in/maityamit" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="ansuman-behera-7b00b61b6" height="30" width="40" /></a>
 <a href="https://instagram.com/amit_maity_2003" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="_ansuman_behera_/" height="30" width="40" /></a>
  <a href="https://twitter.com/AmitMai40525308" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="_ansuman_behera_/" height="30" width="40" /></a>
  <a href="https://github.com/maityamit" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/github.svg" alt="_ansuman_behera_/" height="30" width="40" /></a>
  <a href="https://leetcode.com/maityamit/" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/leet-code.svg" alt="_ansuman_behera_/" height="30" width="40" /></a>
   <a href="https://www.hackerrank.com/maity_amit_coll1" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/hackerrank.svg" alt="_ansuman_behera_/" height="30" width="40" /></a>
