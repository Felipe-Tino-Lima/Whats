package boardsmarkscalculater.example.hellloworld;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;


public class MainActivity extends AppCompatActivity {


    private Button button;
    private EditText editText;
    private TextInputEditText editmensage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button =  findViewById(R.id.button);
        editText = findViewById(R.id.edittext);
        editmensage = findViewById(R.id.editmensage);




        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String string = editText.getText().toString();
                String mensage = editmensage.getText().toString();
                Intent intent =  new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+string+"?text="+mensage));
                startActivity(intent);
            }
        });


    }

}